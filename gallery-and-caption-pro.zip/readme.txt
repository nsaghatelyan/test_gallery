=== Gallery ===
Contributors: Huge-IT
Donate link: https://huge-it.com/wordpress-photo-gallery/
Tags: photo gallery,
Requires at least: 3.0.1
Tested up to: 4.7.2
Stable tag: 10.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Photo Gallery is advanced solution for WordPress Gallery users. 8 advanced and customizable views will help to create beautiful content in minutes.

== Description ==

**Photo Gallery**

= Photo Gallery is advanced solution for WordPress Gallery users. 8 advanced and customizable views will help to create beautiful content in minutes. =

== Installation ==

### Uploading in WordPress Dashboard

1. First download the ZIP file from Wordpress website
2. Log in to your website administrator panel   
3. Go to the 'Add New' in the plugins dashboard, click “Upload Plugin”
4. Upload [WordPress Photo Gallery](https://wordpress.org/plugins/gallery-images/) ZIP file by choosing it from your computer
5. Click **Install** Now button
6. Then click **Activate Plugin** button.
7. You can see the Photo Gallery plugin installed on Wordpress left menu.

### Using The WordPress Plugins Dashboard

1. Go to the 'Add New' in the plugins dashboard
2. Search for 'Photo Gallery Huge-IT'
3. Click **Install** Now button
4. Then click **Activate Plugin** button
5. You can see the plugin installed on Wordpress left menu

### Using FTP

1. Download the ZIP file from Wordpress website
2. Extract the **photo-gallery** directory to your computer
3. Upload the **photo-gallery** directory to the **/wp-content/plugins/** directory
4. Activate the plugin in the Plugin dashboard
5. You can see the plugin installed on Wordpress left menu

Now you can set your Photo Gallery options, images and use our Photo Gallery.