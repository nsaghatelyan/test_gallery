/**
 * Created by user on 22.11.2016.
 */
jQuery(window).load(function () {
    jQuery(document).find('.ph-gallery-wp-loading-icon').hide();
    jQuery(document).find('.ph-gallery-wp-loading-class').css('visibility', 'visible');
});